import React, { Component } from 'react';

// <!-- Top 영역 s -->
class Bottom extends Component {
    render() {
        return (
            <div className="row" id="lay_bottom">
                <p>BOTTOM</p>
            </div>
        );
    }
}

export default Bottom;