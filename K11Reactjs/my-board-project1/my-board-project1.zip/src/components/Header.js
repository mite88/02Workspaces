import React, { Component } from 'react';

// <!-- Top 영역 s -->
class Header extends Component {
    render() {
        return (
            <div className="row" id="lay_top">
                <p>TOP</p>
            </div>
        );
    }
}

export default Header;