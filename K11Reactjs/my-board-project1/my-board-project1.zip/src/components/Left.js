import React, { Component } from 'react';

// <!-- Top 영역 s -->
class Left extends Component {
    render() {
        return (
            <div className="col-lg-2" id="lay_left">
            <p>LEFT</p>
        </div>
        );
    }
}

export default Left;